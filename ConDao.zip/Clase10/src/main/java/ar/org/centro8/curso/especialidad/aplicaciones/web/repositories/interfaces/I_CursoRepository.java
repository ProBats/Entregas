package ar.org.centro8.curso.especialidad.aplicaciones.web.repositories.interfaces;

import java.util.List;

import ar.org.centro8.curso.especialidad.aplicaciones.web.entities.Alumno;
import ar.org.centro8.curso.especialidad.aplicaciones.web.entities.Curso;

public interface I_CursoRepository {
	void save(Curso curso);
	
	void remove(Curso curso);
	
	void restore(Curso curso);
	
	void update(Curso curso);

	int getCantidadAlumnos(Curso curso);
	
	
	List<Curso>getAllAsset();
	
	default Curso getByIdAsset(int id) {
		return getAllAsset()
						.stream()
						.filter(curso->curso.getId()==id)
						.findFirst()
						.orElse(new Curso());
	}
	
	default List<Curso>getLikeTituloAsset(String titulo){
		return getAllAsset()
						.stream()
						.filter(curso->
					                 curso
					                 		.getTitulo()
					                 		.toLowerCase()
					                 		.contains(titulo.toLowerCase()))
						.toList();
	}
	
	
	List<Curso>getAllPasive();
	
	default Curso getByIdPasive(int id) {
		return getAllPasive()
						.stream()
						.filter(curso->curso.getId()==id)
						.findFirst()
						.orElse(new Curso());
	}
	
	default List<Curso>getLikeTituloPasive(String titulo){
		return getAllPasive()
						.stream()
						.filter(curso->
					                 curso
					                 		.getTitulo()
					                 		.toLowerCase()
					                 		.contains(titulo.toLowerCase()))
						.toList();
	}
}
