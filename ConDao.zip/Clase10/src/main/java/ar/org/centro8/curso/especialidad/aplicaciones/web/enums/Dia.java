package ar.org.centro8.curso.especialidad.aplicaciones.web.enums;

public enum Dia {
	LUNES,
	MARTES,
	MIERCOLES,
	JUEVES,
	VIERNES
}
