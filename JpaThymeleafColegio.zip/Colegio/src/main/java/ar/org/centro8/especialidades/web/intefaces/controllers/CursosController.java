package ar.org.centro8.especialidades.web.intefaces.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.centro8.especialidades.web.intefaces.entities.Curso;
import ar.org.centro8.especialidades.web.intefaces.repositories.CursosRepository;

@Controller
public class CursosController {

    private String mensaje="Ingrese los datos del curso a registrar";
    @Autowired
    CursosRepository cr;
    
    //Ir a Pagina Inicio
    @GetMapping("/index")
    public String getIndex(){
        return"index";
    }
    //Pagina Cursos
    @GetMapping("/cursos")
    public String getCursos(@RequestParam(name = "buscarCurso", required = false, defaultValue = "") String buscar,
    Model model){
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("cursos", new Curso());
        model.addAttribute("all", ((List<Curso>)cr.findAll()).stream().filter(a -> a.getProfesor().toLowerCase().contains(buscar.toLowerCase()) ||
                                                                                    a.getTitulo().toLowerCase().contains(buscar.toLowerCase()))
                                                                                    .toList());
        return"cursos";
    }
    @PostMapping("/saveCurso")
    public String guardarCurso(@ModelAttribute Curso curso){
        cr.save(curso);
        if (curso.getId()>=0) {
            mensaje="Se guardo el Curso "+curso.getId();
        }else{
            mensaje="No se pudo Guardar el Curso";
        }
        return "redirect:cursos";

    }

    @RequestMapping("/eliminarCurso/{id}")
    public String eliminarCurso(@PathVariable int id){
        cr.deleteById(id);
        return "redirect:/cursos";
    }

}
