package ar.org.centro8.especialidades.web.intefaces.enums;

public enum Turno {
    MAÑANA,TARDE,NOCHE
}
