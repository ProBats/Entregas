package ar.org.centro8.especialidades.web.intefaces.entities;

import java.util.List;

import ar.org.centro8.especialidades.web.intefaces.enums.Dia;
import ar.org.centro8.especialidades.web.intefaces.enums.Turno;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
@Getter @Setter
@Entity
@Table(name="cursos")
public class Curso {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(unique = true, nullable = false)
    private int id;
    private String titulo;
    private String profesor;
    @Enumerated(value = EnumType.STRING)
    private Dia dia;
    @Enumerated(value = EnumType.STRING)
    private Turno turno;

    @OneToMany(mappedBy = "curso", cascade = CascadeType.REMOVE)
    private List<Alumno> listaAlumno;
    
    public Curso() {
    }

    public Curso(String titulo, String profesor, Dia dia, Turno turno, List<Alumno> listaAlumno) {
        this.titulo = titulo;
        this.profesor = profesor;
        this.dia = dia;
        this.turno = turno;
        this.listaAlumno = listaAlumno;
    }

    public Curso(int id, String titulo, String profesor, Dia dia, Turno turno, List<Alumno> listaAlumno) {
        this.id = id;
        this.titulo = titulo;
        this.profesor = profesor;
        this.dia = dia;
        this.turno = turno;
        this.listaAlumno = listaAlumno;
    }

    

}
