package ar.org.centro8.especialidades.web.intefaces.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import ar.org.centro8.especialidades.web.intefaces.entities.Curso;

@Repository
public interface CursosRepository extends CrudRepository<Curso, Integer> {
    
}
